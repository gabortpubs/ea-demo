# Support

If you run into an issue, sorry about that! We definitely want to make sure that
your experience using the Carbon Design System is the best that it can be.

When this happens, just create an issue on GitHub by filling out the template
and we'll try our best to respond in a reasonable time.
