# [10.0.0](https://github.com/IBM/carbon-elements/tree/master/packages/stylelint-config-elements/compare/v10.0.0-rc.0...v10.0.0) (2019-03-29)



# [10.0.0-rc.0](https://github.com/IBM/carbon-elements/tree/master/packages/stylelint-config-elements/compare/v0.0.1-beta.5...v10.0.0-rc.0) (2019-03-27)



## [0.0.1-beta.5](https://github.com/IBM/carbon-elements/tree/master/packages/stylelint-config-elements/compare/v0.0.1-beta.4...v0.0.1-beta.5) (2019-03-25)



## [0.0.1-beta.4](https://github.com/IBM/carbon-elements/tree/master/packages/stylelint-config-elements/compare/v0.0.1-beta.3...v0.0.1-beta.4) (2019-03-22)



## [0.0.1-beta.3](https://github.com/IBM/carbon-elements/tree/master/packages/stylelint-config-elements/compare/v0.0.1-beta.2...v0.0.1-beta.3) (2019-03-22)



## [0.0.1-beta.2](https://github.com/IBM/carbon-elements/tree/master/packages/stylelint-config-elements/compare/v0.0.1-beta.1...v0.0.1-beta.2) (2019-03-19)



## [0.0.1-beta.1](https://github.com/IBM/carbon-elements/tree/master/packages/stylelint-config-elements/compare/v0.0.1-beta.0...v0.0.1-beta.1) (2019-03-13)


### Features

* **icons:** add scss for high contrast mode ([#388](https://github.com/IBM/carbon-elements/tree/master/packages/stylelint-config-elements/issues/388)) ([c7c37ea](https://github.com/IBM/carbon-elements/tree/master/packages/stylelint-config-elements/commit/c7c37ea))



## [0.0.1-beta.0](https://github.com/IBM/carbon-elements/tree/master/packages/stylelint-config-elements/compare/v0.0.1-alpha.32...v0.0.1-beta.0) (2019-03-07)



## [0.0.1-alpha.32](https://github.com/IBM/carbon-elements/tree/master/packages/stylelint-config-elements/compare/v0.0.1-alpha.31...v0.0.1-alpha.32) (2019-02-12)


### Features

* **stylelint-config-elements:** add lint rule for unset usage ([c0ca2b1](https://github.com/IBM/carbon-elements/tree/master/packages/stylelint-config-elements/commit/c0ca2b1))
* **stylelint-config-elements:** add stylelint ([#333](https://github.com/IBM/carbon-elements/tree/master/packages/stylelint-config-elements/issues/333)) ([94df4a2](https://github.com/IBM/carbon-elements/tree/master/packages/stylelint-config-elements/commit/94df4a2))



