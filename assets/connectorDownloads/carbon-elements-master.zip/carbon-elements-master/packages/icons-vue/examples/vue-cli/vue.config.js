'use strict';

module.exports = {
  baseUrl: process.env.PUBLIC_URL || '/',
};
