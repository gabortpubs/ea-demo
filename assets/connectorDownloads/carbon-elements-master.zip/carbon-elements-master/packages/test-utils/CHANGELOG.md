# [10.0.0](https://github.com/IBM/carbon-elements/tree/master/packages/test-utils/compare/v10.0.0-rc.0...v10.0.0) (2019-03-29)



# [10.0.0-rc.0](https://github.com/IBM/carbon-elements/tree/master/packages/test-utils/compare/v0.0.1-beta.5...v10.0.0-rc.0) (2019-03-27)


### Features

* **test-utils:** add output helper for scss, add support for initial data ([#449](https://github.com/IBM/carbon-elements/tree/master/packages/test-utils/issues/449)) ([b4d9a87](https://github.com/IBM/carbon-elements/tree/master/packages/test-utils/commit/b4d9a87))



## [0.0.1-beta.5](https://github.com/IBM/carbon-elements/tree/master/packages/test-utils/compare/v0.0.1-beta.4...v0.0.1-beta.5) (2019-03-25)



## [0.0.1-beta.4](https://github.com/IBM/carbon-elements/tree/master/packages/test-utils/compare/v0.0.1-beta.3...v0.0.1-beta.4) (2019-03-22)



## [0.0.1-beta.3](https://github.com/IBM/carbon-elements/tree/master/packages/test-utils/compare/v0.0.1-beta.2...v0.0.1-beta.3) (2019-03-22)


### Features

* **test-utils:** make test-utils public ([#446](https://github.com/IBM/carbon-elements/tree/master/packages/test-utils/issues/446)) ([7f86f8f](https://github.com/IBM/carbon-elements/tree/master/packages/test-utils/commit/7f86f8f))
* **theme:** add theme maps and theme mixin ([#397](https://github.com/IBM/carbon-elements/tree/master/packages/test-utils/issues/397)) ([a91e527](https://github.com/IBM/carbon-elements/tree/master/packages/test-utils/commit/a91e527))



