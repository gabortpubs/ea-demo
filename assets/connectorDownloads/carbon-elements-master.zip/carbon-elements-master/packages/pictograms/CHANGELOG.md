# [10.0.0](https://github.com/IBM/carbon-elements/tree/master/packages/pictograms/compare/v10.0.0-rc.0...v10.0.0) (2019-03-29)



# [10.0.0-rc.0](https://github.com/IBM/carbon-elements/tree/master/packages/pictograms/compare/v0.0.1-beta.5...v10.0.0-rc.0) (2019-03-27)



## [0.0.1-beta.5](https://github.com/IBM/carbon-elements/tree/master/packages/pictograms/compare/v0.0.1-beta.4...v0.0.1-beta.5) (2019-03-25)



## [0.0.1-beta.4](https://github.com/IBM/carbon-elements/tree/master/packages/pictograms/compare/v0.0.1-beta.3...v0.0.1-beta.4) (2019-03-22)



## [0.0.1-beta.3](https://github.com/IBM/carbon-elements/tree/master/packages/pictograms/compare/v0.0.1-beta.2...v0.0.1-beta.3) (2019-03-22)



## [0.0.1-beta.2](https://github.com/IBM/carbon-elements/tree/master/packages/pictograms/compare/v0.0.1-beta.1...v0.0.1-beta.2) (2019-03-19)



## [0.0.1-beta.1](https://github.com/IBM/carbon-elements/tree/master/packages/pictograms/compare/v0.0.1-beta.0...v0.0.1-beta.1) (2019-03-13)



## [0.0.1-beta.0](https://github.com/IBM/carbon-elements/tree/master/packages/pictograms/compare/v0.0.1-alpha.32...v0.0.1-beta.0) (2019-03-07)



## [0.0.1-alpha.32](https://github.com/IBM/carbon-elements/tree/master/packages/pictograms/compare/v0.0.1-alpha.31...v0.0.1-alpha.32) (2019-02-12)


### Features

* **pictograms:** setup the package folder for pictograms ([#317](https://github.com/IBM/carbon-elements/tree/master/packages/pictograms/issues/317)) ([f43154a](https://github.com/IBM/carbon-elements/tree/master/packages/pictograms/commit/f43154a))



