# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# 10.1.0 (2019-04-12)


### Features

* **scss-generator:** add scss-generator package ([#475](https://github.com/IBM/carbon-elements/tree/master/packages/scss-generator/issues/475)) ([abbd06f](https://github.com/IBM/carbon-elements/tree/master/packages/scss-generator/commit/abbd06f))
