# Project moved to [`carbon-design-system/carbon`](https://github.com/carbon-design-system/carbon)

This project has been moved to the Carbon monorepo. For more information about
this transition, you can check out [this post](https://medium.com/carbondesign/carbon-is-moving-to-a-monorepo-c6bfcbe87de0).

All issues and pull requests for this package should be made on that repo
instead.
