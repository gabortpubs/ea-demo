# e2e

> Documentation for running end-to-end tests for Carbon Elements

## Usage

```bash
yarn test:e2e
```

## About

End-to-end tests are ones that can potentially take a large amount of time to
execute, and may also require the project to be in a built state before running.
